package com.mikasa.assistant.domain.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject

/** Friendly name -> package name. Extend this map (and the <queries> block in the
 * manifest) to teach Mikasa about more apps. */
val KNOWN_APPS = mapOf(
    "whatsapp" to "com.whatsapp",
    "telegram" to "org.telegram.messenger",
    "instagram" to "com.instagram.android",
    "youtube" to "com.google.android.youtube",
    "spotify" to "com.spotify.music",
    "gmail" to "com.google.android.gm",
    "chrome" to "com.android.chrome",
    "maps" to "com.google.android.apps.maps"
)

class OpenAppTool(private val context: Context) : AssistantTool {
    override val name = "open_app"
    override val description = "Open any installed app by its common name, e.g. WhatsApp, Telegram, Instagram, YouTube, Spotify."
    override val parametersJson = """{"type":"object","properties":{"app_name":{"type":"string"}},"required":["app_name"]}"""

    override suspend fun execute(arguments: JSONObject): ToolResult {
        val spoken = arguments.getString("app_name").trim().lowercase()
        val packageName = KNOWN_APPS[spoken]
            ?: return ToolResult(false, "I don't know \"$spoken\" yet — add it to KNOWN_APPS in AppAndMediaTools.kt (and the manifest <queries>).")

        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return ToolResult(false, "$spoken isn't installed on this phone.")
        launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(launchIntent)
        return ToolResult(true, "Opening $spoken.")
    }
}

class WebSearchTool(private val context: Context) : AssistantTool {
    override val name = "web_search"
    override val description = "Search the web for a query and open the results in the browser."
    override val parametersJson = """{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}"""

    override suspend fun execute(arguments: JSONObject): ToolResult {
        val query = arguments.getString("query")
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return ToolResult(true, "Searching the web for \"$query\".")
    }
}

class PlayMediaTool(private val context: Context) : AssistantTool {
    override val name = "play_media"
    override val description = "Play a song, artist or video by opening it in YouTube or Spotify."
    override val parametersJson = """
        {"type":"object","properties":{
          "query":{"type":"string"},"app":{"type":"string","description":"\"youtube\" or \"spotify\""}
        },"required":["query"]}
    """.trimIndent()

    override suspend fun execute(arguments: JSONObject): ToolResult {
        val query = arguments.getString("query")
        val app = arguments.optString("app", "youtube")
        val intent = if (app == "spotify") {
            Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(query)))
        } else {
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)))
        }
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        return try {
            context.startActivity(intent)
            ToolResult(true, "Playing $query.")
        } catch (e: Exception) {
            ToolResult(false, "Couldn't open $app — is it installed?")
        }
    }
}
