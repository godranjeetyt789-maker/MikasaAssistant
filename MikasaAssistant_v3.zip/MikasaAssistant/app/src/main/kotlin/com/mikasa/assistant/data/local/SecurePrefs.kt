package com.mikasa.assistant.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores the user's own xAI API key (entered once in Settings) using
 * Android's EncryptedSharedPreferences — AES-256 encrypted at rest, tied to
 * the Android Keystore. The key never lives in source code or in plain text.
 */
class SecurePrefs(context: Context) {

    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            "mikasa_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    var xaiApiKey: String?
        get() = prefs.getString(KEY_XAI_API_KEY, null)
        set(value) = prefs.edit().putString(KEY_XAI_API_KEY, value).apply()

    var assistantName: String
        get() = prefs.getString(KEY_ASSISTANT_NAME, "Mikasa") ?: "Mikasa"
        set(value) = prefs.edit().putString(KEY_ASSISTANT_NAME, value).apply()

    var preferredLanguage: String
        get() = prefs.getString(KEY_LANGUAGE, "hinglish") ?: "hinglish" // "hindi" | "english" | "hinglish"
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    fun hasApiKey(): Boolean = !xaiApiKey.isNullOrBlank()

    companion object {
        private const val KEY_XAI_API_KEY = "xai_api_key"
        private const val KEY_ASSISTANT_NAME = "assistant_name"
        private const val KEY_LANGUAGE = "preferred_language"
    }
}
