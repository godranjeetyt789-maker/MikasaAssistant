package com.mikasa.assistant.domain.tools

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import org.json.JSONObject

internal fun hasPermission(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

/** Resolves a spoken contact name to a phone number (falls back to treating input as a number). */
internal fun resolvePhoneNumber(context: Context, nameOrNumber: String): String? {
    val digitCount = nameOrNumber.count { it.isDigit() }
    if (digitCount >= 7) return nameOrNumber // already looks like a number

    if (!hasPermission(context, Manifest.permission.READ_CONTACTS)) return null
    val uri = Uri.withAppendedPath(
        ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI,
        Uri.encode(nameOrNumber)
    )
    context.contentResolver.query(
        uri, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null
    )?.use { cursor -> if (cursor.moveToFirst()) return cursor.getString(0) }
    return null
}

/** No permission needed — hands off to the Clock app via a public system intent. */
class SetAlarmTool(private val context: Context) : AssistantTool {
    override val name = "set_alarm"
    override val description = "Set an alarm on the phone's Clock app for a given time, optionally with a label."
    override val parametersJson = """
        {"type":"object","properties":{
          "hour":{"type":"integer","description":"0-23"},
          "minute":{"type":"integer","description":"0-59"},
          "label":{"type":"string"}
        },"required":["hour","minute"]}
    """.trimIndent()

    override suspend fun execute(arguments: JSONObject): ToolResult {
        val hour = arguments.getInt("hour")
        val minute = arguments.getInt("minute")
        val label = arguments.optString("label", "Mikasa alarm")
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            ToolResult(true, "Alarm set for %02d:%02d.".format(hour, minute))
        } else {
            ToolResult(false, "No Clock app found on this phone.")
        }
    }
}

/** Opens the Calendar app pre-filled — no WRITE_CALENDAR permission required, user taps save. */
class CreateCalendarEventTool(private val context: Context) : AssistantTool {
    override val name = "create_calendar_event"
    override val description = "Create a calendar event. Opens the Calendar app pre-filled for the user to confirm and save."
    override val parametersJson = """
        {"type":"object","properties":{
          "title":{"type":"string"},
          "start_time_millis":{"type":"integer","description":"epoch millis"},
          "end_time_millis":{"type":"integer","description":"epoch millis"},
          "location":{"type":"string"}
        },"required":["title","start_time_millis","end_time_millis"]}
    """.trimIndent()

    override suspend fun execute(arguments: JSONObject): ToolResult {
        val title = arguments.getString("title")
        val start = arguments.getLong("start_time_millis")
        val end = arguments.getLong("end_time_millis")
        val location = arguments.optString("location", "")
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.Events.TITLE, title)
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
            if (location.isNotBlank()) putExtra(CalendarContract.Events.EVENT_LOCATION, location)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            ToolResult(true, "Opened Calendar with \"$title\" filled in — just tap save.")
        } else {
            ToolResult(false, "No Calendar app found on this phone.")
        }
    }
}

/** Requires the CALL_PHONE runtime permission for one-tap dialing; falls back to the dialer otherwise. */
class PlaceCallTool(private val context: Context) : AssistantTool {
    override val name = "place_call"
    override val description = "Call a contact by name or a phone number."
    override val parametersJson = """
        {"type":"object","properties":{"contact_or_number":{"type":"string"}},"required":["contact_or_number"]}
    """.trimIndent()
    override val requiresConfirmation = true
    override fun confirmationSummary(arguments: JSONObject) = "Call ${arguments.optString("contact_or_number")}?"

    override suspend fun execute(arguments: JSONObject): ToolResult {
        val target = arguments.getString("contact_or_number")
        val number = resolvePhoneNumber(context, target)
            ?: return ToolResult(false, "Couldn't find a number for \"$target\" — add them to Contacts or say the number directly.")

        val canDirectDial = hasPermission(context, Manifest.permission.CALL_PHONE)
        val intent = Intent(if (canDirectDial) Intent.ACTION_CALL else Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$number")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return if (canDirectDial) {
            ToolResult(true, "Calling $target.")
        } else {
            ToolResult(true, "Opened the dialer for $target — grant the Phone permission in Settings for one-tap calling.")
        }
    }
}

/** Requires the SEND_SMS runtime permission. Always confirmed before sending. */
class SendSmsTool(private val context: Context) : AssistantTool {
    override val name = "send_sms"
    override val description = "Send a text message to a contact by name or number."
    override val parametersJson = """
        {"type":"object","properties":{
          "contact_or_number":{"type":"string"},"message":{"type":"string"}
        },"required":["contact_or_number","message"]}
    """.trimIndent()
    override val requiresConfirmation = true
    override fun confirmationSummary(arguments: JSONObject) =
        "Send SMS to ${arguments.optString("contact_or_number")}: \"${arguments.optString("message")}\"?"

    override suspend fun execute(arguments: JSONObject): ToolResult {
        val target = arguments.getString("contact_or_number")
        val message = arguments.getString("message")
        val number = resolvePhoneNumber(context, target)
            ?: return ToolResult(false, "Couldn't find a number for \"$target\".")
        if (!hasPermission(context, Manifest.permission.SEND_SMS)) {
            return ToolResult(false, "SMS permission isn't granted yet — enable it in Settings to send texts.")
        }
        return try {
            SmsManager.getDefault().sendTextMessage(number, null, message, null, null)
            ToolResult(true, "Sent to $target.")
        } catch (e: Exception) {
            ToolResult(false, "Couldn't send the SMS: ${e.message}")
        }
    }
}

/** Requires READ_SMS. Read-only, only runs when the user explicitly asks. */
class ReadRecentSmsTool(private val context: Context) : AssistantTool {
    override val name = "read_recent_sms"
    override val description = "Read the most recent SMS messages from the inbox."
    override val parametersJson = """{"type":"object","properties":{"count":{"type":"integer"}}}"""

    override suspend fun execute(arguments: JSONObject): ToolResult {
        if (!hasPermission(context, Manifest.permission.READ_SMS)) {
            return ToolResult(false, "SMS read permission isn't granted yet — enable it in Settings.")
        }
        val count = if (arguments.has("count")) arguments.getInt("count") else 5
        val sb = StringBuilder()
        context.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("address", "body"), null, null, "date DESC"
        )?.use { cursor ->
            var i = 0
            while (cursor.moveToNext() && i < count) {
                sb.append("From ${cursor.getString(0)}: ${cursor.getString(1)}\n")
                i++
            }
        }
        return if (sb.isEmpty()) ToolResult(true, "No recent messages.") else ToolResult(true, sb.toString().trim())
    }
}
