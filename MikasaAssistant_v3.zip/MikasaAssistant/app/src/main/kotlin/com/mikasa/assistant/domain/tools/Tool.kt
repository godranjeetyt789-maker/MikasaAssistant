package com.mikasa.assistant.domain.tools

import com.mikasa.assistant.data.remote.ToolDefinition
import org.json.JSONObject

/**
 * Result of executing one tool. [needsConfirmation] lets a tool say "don't
 * actually do this yet — show the user a confirm dialog first" for anything
 * sensitive (sending a message, placing a call, etc). The ViewModel checks
 * this flag before calling [AssistantTool.execute] for real.
 */
data class ToolResult(
    val success: Boolean,
    val messageForUser: String,   // spoken/shown to the human
    val messageForGrok: String = messageForUser // fed back into the conversation as the tool result
)

data class ConfirmationRequest(
    val toolName: String,
    val summary: String,          // e.g. "Send SMS to Rahul: \"On my way\"?"
    val arguments: JSONObject
)

/**
 * Implement this interface to add a new skill to Mikasa. Register your
 * instance in [ToolRegistry.buildDefault] (or anywhere with access to the
 * registry) and Grok will be able to call it like any built-in tool.
 */
interface AssistantTool {
    val name: String
    val description: String
    /** JSON-schema "parameters" object as a raw string, e.g. {"type":"object","properties":{...}} */
    val parametersJson: String

    /** True for anything that sends/spends/contacts on the user's behalf. */
    val requiresConfirmation: Boolean get() = false

    fun confirmationSummary(arguments: JSONObject): String = "$name(${arguments})"

    suspend fun execute(arguments: JSONObject): ToolResult
}

class ToolRegistry {
    private val tools = mutableMapOf<String, AssistantTool>()

    fun register(tool: AssistantTool) {
        tools[tool.name] = tool
    }

    fun get(name: String): AssistantTool? = tools[name]

    fun definitionsForGrok(): List<ToolDefinition> = tools.values.map {
        ToolDefinition(name = it.name, description = it.description, parametersJson = it.parametersJson)
    }
}
