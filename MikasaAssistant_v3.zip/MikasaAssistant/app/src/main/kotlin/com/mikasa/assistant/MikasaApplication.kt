package com.mikasa.assistant

import android.app.Application
import com.mikasa.assistant.di.AppContainer

class MikasaApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
