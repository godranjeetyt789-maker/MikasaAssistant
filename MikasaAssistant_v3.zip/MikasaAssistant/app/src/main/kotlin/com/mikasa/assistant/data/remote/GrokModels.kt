package com.mikasa.assistant.data.remote

/**
 * Plain data models for the xAI (Grok) /v1/chat/completions endpoint.
 * The API is OpenAI-compatible, so these mirror that shape.
 * Docs: https://docs.x.ai/docs/api-reference
 */

data class ChatMessage(
    val role: String,               // "system" | "user" | "assistant" | "tool"
    val content: String? = null,
    val toolCalls: List<ToolCall>? = null,   // present on assistant messages that call a tool
    val toolCallId: String? = null,          // present on "tool" role messages (the result)
    val name: String? = null                 // tool name, present on "tool" role messages
)

data class ToolCall(
    val id: String,
    val type: String = "function",
    val functionName: String,
    val functionArgumentsJson: String  // raw JSON string of arguments, per OpenAI-compatible spec
)

data class ToolDefinition(
    val name: String,
    val description: String,
    /** JSON-schema-shaped parameters object, e.g. {"type":"object","properties":{...},"required":[...]} */
    val parametersJson: String
)

/** Result of one turn: either a spoken reply, or a list of tool calls Grok wants executed. */
sealed class GrokTurnResult {
    data class Reply(val text: String) : GrokTurnResult()
    data class ToolCalls(val calls: List<ToolCall>) : GrokTurnResult()
    data class Error(val message: String) : GrokTurnResult()
}
