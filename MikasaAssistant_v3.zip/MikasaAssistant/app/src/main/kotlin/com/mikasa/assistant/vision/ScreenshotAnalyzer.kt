package com.mikasa.assistant.vision

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * One-shot "what's on my screen?" capture, triggered only when the user asks.
 *
 * Every call goes through Android's own MediaProjection consent dialog —
 * no app, including this one, can suppress or pre-approve it. That OS-level
 * guarantee (re-confirmed every time, one frame only, never a continuous
 * feed) is exactly what keeps this feature different from a general
 * Accessibility screen-scraper.
 *
 * Wiring: call [createCaptureIntent] and launch it with
 * registerForActivityResult(ActivityResultContracts.StartActivityForResult())
 * from MainActivity; when it returns RESULT_OK, pass resultCode/data into
 * [captureOnce].
 */
class ScreenshotAnalyzer(private val context: Context) {

    fun createCaptureIntent(projectionManager: MediaProjectionManager): Intent =
        projectionManager.createScreenCaptureIntent()

    suspend fun captureOnce(
        projectionManager: MediaProjectionManager,
        resultCode: Int,
        resultData: Intent
    ): Bitmap? = suspendCancellableCoroutine { cont ->
        val metrics = DisplayMetrics()
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        val projection: MediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
        val imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        var virtualDisplay: VirtualDisplay? = null
        val handler = Handler(Looper.getMainLooper())

        imageReader.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * width

            val bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(plane.buffer)
            image.close()
            virtualDisplay?.release()
            projection.stop()

            if (cont.isActive) cont.resume(Bitmap.createBitmap(bitmap, 0, 0, width, height))
        }, handler)

        virtualDisplay = projection.createVirtualDisplay(
            "MikasaScreenCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.surface, null, handler
        )

        cont.invokeOnCancellation {
            virtualDisplay?.release()
            projection.stop()
        }
    }
}
