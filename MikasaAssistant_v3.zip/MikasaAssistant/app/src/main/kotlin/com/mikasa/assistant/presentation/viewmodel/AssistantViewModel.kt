package com.mikasa.assistant.presentation.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mikasa.assistant.MikasaApplication
import com.mikasa.assistant.domain.EngineEvent
import com.mikasa.assistant.domain.EngineState
import com.mikasa.assistant.domain.tools.ConfirmationRequest
import com.mikasa.assistant.voice.SpeechResult
import com.mikasa.assistant.voice.TextToSpeechManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AssistantState { IDLE, LISTENING, THINKING, SPEAKING, AWAITING_CONFIRMATION }

data class UiMessage(val role: String, val text: String)

data class AssistantUiState(
    val state: AssistantState = AssistantState.IDLE,
    val messages: List<UiMessage> = emptyList(),
    val pendingConfirmation: ConfirmationRequest? = null,
    val amplitude: Float = 0f,
    val errorMessage: String? = null
)

class AssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val container get() = (getApplication<Application>() as MikasaApplication).container
    private val engine get() = container.conversationEngine

    private val _uiState = MutableStateFlow(AssistantUiState())
    val uiState: StateFlow<AssistantUiState> = _uiState.asStateFlow()

    init {
        container.speechToText.onAmplitude = { rms -> _uiState.value = _uiState.value.copy(amplitude = rms) }
        viewModelScope.launch {
            engine.loadHistory()
            _uiState.value = _uiState.value.copy(
                messages = engine.historySnapshot()
                    .filter { it.content != null }
                    .map { UiMessage(it.role, it.content!!) }
            )
        }
    }

    fun startListening() {
        if (_uiState.value.state != AssistantState.IDLE) return
        _uiState.value = _uiState.value.copy(state = AssistantState.LISTENING, errorMessage = null)
        viewModelScope.launch {
            val languageTag = if (container.securePrefs.preferredLanguage == "hindi") "hi-IN" else "en-IN"
            when (val result = container.speechToText.listenOnce(languageTag)) {
                is SpeechResult.Text -> submit(result.text)
                is SpeechResult.Error -> _uiState.value =
                    _uiState.value.copy(state = AssistantState.IDLE, errorMessage = result.message)
            }
        }
    }

    fun submitTypedText(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch { submit(text) }
    }

    fun confirmPendingAction(approved: Boolean) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(pendingConfirmation = null, state = AssistantState.THINKING)
            applyEvent(engine.confirmPendingAction(approved))
        }
    }

    private suspend fun submit(text: String) {
        _uiState.value = _uiState.value.copy(
            messages = _uiState.value.messages + UiMessage("user", text),
            state = AssistantState.THINKING
        )
        applyEvent(engine.handleUserUtterance(text))
    }

    private suspend fun applyEvent(event: EngineEvent) {
        when (event.state) {
            EngineState.AWAITING_CONFIRMATION -> {
                _uiState.value = _uiState.value.copy(
                    state = AssistantState.AWAITING_CONFIRMATION,
                    pendingConfirmation = event.pendingConfirmation
                )
            }
            EngineState.THINKING -> {
                _uiState.value = _uiState.value.copy(state = AssistantState.THINKING)
            }
            EngineState.IDLE -> {
                if (event.error != null) {
                    _uiState.value = _uiState.value.copy(state = AssistantState.IDLE, errorMessage = event.error)
                    return
                }
                event.spokenReply?.let { reply ->
                    _uiState.value = _uiState.value.copy(messages = _uiState.value.messages + UiMessage("assistant", reply))
                    speak(reply)
                }
                _uiState.value = _uiState.value.copy(state = AssistantState.IDLE)
            }
        }
    }

    private suspend fun speak(text: String) {
        _uiState.value = _uiState.value.copy(state = AssistantState.SPEAKING)
        val mood = when {
            text.contains("!") -> TextToSpeechManager.Mood.EXCITED
            text.contains("sorry", ignoreCase = true) || text.contains("maaf", ignoreCase = true) -> TextToSpeechManager.Mood.CALM
            else -> TextToSpeechManager.Mood.WARM
        }
        container.textToSpeech.speak(text, mood)
    }

    override fun onCleared() {
        super.onCleared()
        container.speechToText.destroy()
        container.textToSpeech.shutdown()
    }
}
