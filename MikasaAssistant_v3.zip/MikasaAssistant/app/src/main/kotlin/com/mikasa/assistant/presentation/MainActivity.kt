package com.mikasa.assistant.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mikasa.assistant.R
import com.mikasa.assistant.presentation.ui.screens.AssistantScreen
import com.mikasa.assistant.presentation.ui.screens.SettingsScreen
import com.mikasa.assistant.presentation.ui.theme.ElectricViolet
import com.mikasa.assistant.presentation.ui.theme.MikasaTheme
import com.mikasa.assistant.presentation.ui.theme.NeonCyan
import com.mikasa.assistant.presentation.ui.theme.SurfaceDark

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MikasaTheme {
                var currentTab by remember { mutableStateOf(0) }
                Column(Modifier.fillMaxSize().background(SurfaceDark)) {
                    Box(Modifier.weight(1f)) {
                        when (currentTab) {
                            0 -> AssistantScreen()
                            1 -> SettingsScreen()
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().background(Color(0xFF0A0A18)),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("Chat" to 0, "Settings" to 1).forEach { (label, idx) ->
                            val active = currentTab == idx
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable { currentTab = idx }
                                    .padding(vertical = 10.dp, horizontal = 24.dp)
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_notification),
                                    contentDescription = label,
                                    tint = if (active) NeonCyan else ElectricViolet.copy(alpha = 0.5f),
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(label, color = if (active) NeonCyan else Color(0xFF606090), fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
