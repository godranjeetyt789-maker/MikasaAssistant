package com.mikasa.assistant.di

import android.content.Context
import androidx.room.Room
import com.mikasa.assistant.data.local.ConversationDatabase
import com.mikasa.assistant.data.local.SecurePrefs
import com.mikasa.assistant.data.remote.GrokApiService
import com.mikasa.assistant.domain.ConversationEngine
import com.mikasa.assistant.domain.tools.CreateCalendarEventTool
import com.mikasa.assistant.domain.tools.OpenAppTool
import com.mikasa.assistant.domain.tools.PlaceCallTool
import com.mikasa.assistant.domain.tools.PlayMediaTool
import com.mikasa.assistant.domain.tools.ReadNotificationsTool
import com.mikasa.assistant.domain.tools.ReadRecentSmsTool
import com.mikasa.assistant.domain.tools.SendSmsTool
import com.mikasa.assistant.domain.tools.SetAlarmTool
import com.mikasa.assistant.domain.tools.ToolRegistry
import com.mikasa.assistant.domain.tools.WebSearchTool
import com.mikasa.assistant.vision.ScreenshotAnalyzer
import com.mikasa.assistant.voice.SpeechToTextManager
import com.mikasa.assistant.voice.TextToSpeechManager

/**
 * Simple hand-rolled DI container (no Hilt/Koin), so there's one fewer
 * Gradle plugin to fight with the first time you build this. Swap in Hilt
 * later if you prefer — nothing else here depends on it being absent.
 */
class AppContainer(context: Context) {
    val securePrefs = SecurePrefs(context)

    val database: ConversationDatabase = Room.databaseBuilder(
        context.applicationContext, ConversationDatabase::class.java, "mikasa_conversations.db"
    ).build()

    val grokApiService = GrokApiService(apiKeyProvider = { securePrefs.xaiApiKey })

    /** The whole plugin system: implement AssistantTool (see Tool.kt) and register it here. */
    val toolRegistry = ToolRegistry().apply {
        register(SetAlarmTool(context))
        register(CreateCalendarEventTool(context))
        register(PlaceCallTool(context))
        register(SendSmsTool(context))
        register(ReadRecentSmsTool(context))
        register(OpenAppTool(context))
        register(WebSearchTool(context))
        register(PlayMediaTool(context))
        register(ReadNotificationsTool())
    }

    val speechToText = SpeechToTextManager(context)
    val textToSpeech = TextToSpeechManager(context)
    val screenshotAnalyzer = ScreenshotAnalyzer(context)

    /** Shared by the on-screen chat and the wake-word service — one live conversation. */
    val conversationEngine = ConversationEngine(grokApiService, toolRegistry, securePrefs, database.conversationDao())
}
