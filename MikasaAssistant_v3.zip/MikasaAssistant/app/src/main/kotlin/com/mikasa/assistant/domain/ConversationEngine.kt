package com.mikasa.assistant.domain

import com.mikasa.assistant.data.local.ConversationDao
import com.mikasa.assistant.data.local.MessageEntity
import com.mikasa.assistant.data.local.SecurePrefs
import com.mikasa.assistant.data.remote.ChatMessage
import com.mikasa.assistant.data.remote.GrokApiService
import com.mikasa.assistant.data.remote.GrokTurnResult
import com.mikasa.assistant.data.remote.ToolCall
import com.mikasa.assistant.domain.tools.ConfirmationRequest
import com.mikasa.assistant.domain.tools.ToolRegistry
import org.json.JSONObject

enum class EngineState { IDLE, THINKING, AWAITING_CONFIRMATION }

data class EngineEvent(
    val state: EngineState,
    val pendingConfirmation: ConfirmationRequest? = null,
    val spokenReply: String? = null,
    val error: String? = null
)

/**
 * The actual "brain loop": send the conversation to Grok, execute any tool
 * calls it asks for (pausing for confirmation on sensitive ones), feed the
 * results back, and repeat until Grok gives a plain-language reply.
 *
 * One shared instance (see AppContainer) is used by both the on-screen chat
 * (AssistantViewModel) and the wake-word background service, so a
 * conversation started by voice and continued by typing (or vice versa)
 * never drifts out of sync. This class has no Android UI dependency — it
 * only knows about tools, the API client and storage — which is what keeps
 * it testable and reusable across entry points.
 */
class ConversationEngine(
    private val grokApiService: GrokApiService,
    private val toolRegistry: ToolRegistry,
    private val securePrefs: SecurePrefs,
    private val conversationDao: ConversationDao
) {
    private val history = mutableListOf<ChatMessage>()
    private var pendingToolCall: ToolCall? = null

    suspend fun loadHistory(limit: Int = 20) {
        val recent = conversationDao.recent(limit).reversed()
        history.clear()
        history.addAll(recent.map { ChatMessage(role = it.role, content = it.content) })
    }

    fun historySnapshot(): List<ChatMessage> = history.toList()

    suspend fun handleUserUtterance(text: String): EngineEvent {
        remember("user", text)
        return runTurn()
    }

    suspend fun confirmPendingAction(approved: Boolean): EngineEvent {
        val call = pendingToolCall ?: return EngineEvent(state = EngineState.IDLE)
        pendingToolCall = null
        val tool = toolRegistry.get(call.functionName)
        val args = safeArgs(call)
        val resultText = if (approved && tool != null) tool.execute(args).messageForGrok else "User declined this action."
        appendToolExchange(call, resultText)
        return runTurn()
    }

    private suspend fun runTurn(): EngineEvent {
        val messages = listOf(ChatMessage(role = "system", content = systemPrompt())) + history
        return when (val result = grokApiService.sendTurn(messages, toolRegistry.definitionsForGrok())) {
            is GrokTurnResult.Reply -> {
                remember("assistant", result.text)
                EngineEvent(state = EngineState.IDLE, spokenReply = result.text)
            }
            is GrokTurnResult.ToolCalls -> {
                for (call in result.calls) {
                    val tool = toolRegistry.get(call.functionName)
                    val args = safeArgs(call)
                    if (tool == null) {
                        appendToolExchange(call, "Unknown tool ${call.functionName}")
                        continue
                    }
                    if (tool.requiresConfirmation) {
                        pendingToolCall = call
                        return EngineEvent(
                            state = EngineState.AWAITING_CONFIRMATION,
                            pendingConfirmation = ConfirmationRequest(tool.name, tool.confirmationSummary(args), args)
                        )
                    }
                    appendToolExchange(call, tool.execute(args).messageForGrok)
                }
                runTurn() // let Grok wrap up in natural language now that tool results are in history
            }
            is GrokTurnResult.Error -> EngineEvent(state = EngineState.IDLE, error = result.message)
        }
    }

    private fun safeArgs(call: ToolCall): JSONObject =
        try { JSONObject(call.functionArgumentsJson) } catch (e: Exception) { JSONObject() }

    private suspend fun remember(role: String, content: String) {
        history.add(ChatMessage(role = role, content = content))
        conversationDao.insert(MessageEntity(role = role, content = content))
    }

    private fun appendToolExchange(call: ToolCall, resultText: String) {
        history.add(ChatMessage(role = "assistant", content = null, toolCalls = listOf(call)))
        history.add(ChatMessage(role = "tool", content = resultText, toolCallId = call.id, name = call.functionName))
    }

    private fun systemPrompt(): String {
        val name = securePrefs.assistantName
        return """
            You are $name, a warm and emotionally expressive personal AI assistant living on the
            user's Android phone. Reply naturally in whichever mix of Hindi, English or Hinglish
            the user is using — mirror their style. Keep replies conversational and fairly short,
            like a real spoken exchange, not a written essay. You have tools to actually take
            action on the phone (alarms, calendar, calls, texts, opening apps, media, web search,
            notifications) — use them whenever the user asks for something actionable, don't just
            describe what you'd do. Sensitive actions are confirmed with the user by the app
            itself before they happen, so you can propose them confidently.
        """.trimIndent()
    }
}
