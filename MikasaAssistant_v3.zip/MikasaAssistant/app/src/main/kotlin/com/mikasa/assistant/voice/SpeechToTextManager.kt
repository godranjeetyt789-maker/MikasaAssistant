package com.mikasa.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

sealed class SpeechResult {
    data class Text(val text: String) : SpeechResult()
    data class Error(val message: String) : SpeechResult()
}

/**
 * Wraps Android's on-device SpeechRecognizer for one-shot "listen for a
 * command" turns, invoked directly (no system popup) so a custom waveform UI
 * can be shown instead.
 */
class SpeechToTextManager(private val context: Context) {

    /** Optional hook for driving a live waveform UI while listening. */
    var onAmplitude: ((Float) -> Unit)? = null

    private var recognizer: SpeechRecognizer? = null

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    suspend fun listenOnce(languageTag: String = "en-IN"): SpeechResult = suspendCancellableCoroutine { cont ->
        if (!isAvailable()) {
            cont.resume(SpeechResult.Error("Speech recognition isn't available on this device."))
            return@suspendCancellableCoroutine
        }

        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag) // "hi-IN" also works well for Hinglish
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle) {
                val text = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (cont.isActive) {
                    cont.resume(if (text != null) SpeechResult.Text(text) else SpeechResult.Error("Didn't catch that."))
                }
                r.destroy()
            }
            override fun onError(error: Int) {
                if (cont.isActive) cont.resume(SpeechResult.Error("Recognition error code $error"))
                r.destroy()
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { onAmplitude?.invoke(rmsdB) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        cont.invokeOnCancellation {
            r.stopListening()
            r.destroy()
        }
        r.startListening(intent)
    }

    fun destroy() {
        recognizer?.destroy()
        recognizer = null
    }
}
