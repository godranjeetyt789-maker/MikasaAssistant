package com.mikasa.assistant.domain.tools

import com.mikasa.assistant.service.NotificationReaderService
import org.json.JSONObject

class ReadNotificationsTool : AssistantTool {
    override val name = "read_notifications"
    override val description = "Read a summary of the phone's current notifications (app name + title only)."
    override val parametersJson = """{"type":"object","properties":{}}"""

    override suspend fun execute(arguments: JSONObject): ToolResult {
        if (!NotificationReaderService.isEnabled) {
            return ToolResult(false, "Notification access isn't granted yet — enable it in Settings.")
        }
        val current = NotificationReaderService.currentSnapshot()
        return if (current.isEmpty()) {
            ToolResult(true, "No active notifications right now.")
        } else {
            ToolResult(true, current.joinToString("\n") { "${it.appName}: ${it.title}" })
        }
    }
}
