package com.mikasa.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.mikasa.assistant.MikasaApplication
import com.mikasa.assistant.R
import com.mikasa.assistant.domain.EngineState
import com.mikasa.assistant.presentation.MainActivity
import com.mikasa.assistant.voice.SpeechResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground service that listens for a wake word ("Hey Mikasa") and, once
 * detected, runs one turn of the shared ConversationEngine headlessly,
 * speaking the reply via TTS. Android requires a visible, persistent
 * notification for any service that keeps the microphone open in the
 * background — that's a deliberate OS transparency measure this app leans
 * into rather than works around.
 *
 * WAKE WORD ENGINE
 * A robust custom wake-word model ("Hey Mikasa") is a real ML project on its
 * own (audio dataset + training pipeline) — not something to hand-roll here.
 * This scaffolds the integration point for Picovoice Porcupine instead: a
 * well-established, on-device, battery-friendly wake-word SDK with a free
 * tier and a web console for training a custom wake word:
 *   1. https://console.picovoice.ai -> create a free AccessKey
 *   2. Train a "Hey Mikasa" (or "Jarvis") .ppn wake-word file there
 *   3. Uncomment the Porcupine dependency in app/build.gradle.kts and the
 *      maven.picovoice.ai repository in settings.gradle.kts
 *   4. Put the .ppn file in app/src/main/assets/ and construct a
 *      PorcupineManager in onCreate() below, calling onWakeWordDetected()
 *      from its wake-word callback.
 * Until that's wired in, the mic button in MainActivity / the floating
 * bubble starts a listening turn directly — the rest of the app works fully
 * without hands-free wake-word activation.
 */
class AssistantForegroundService : Service() {

    private val scope = CoroutineScope(Dispatchers.Default + Job())

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification("Listening for \"Hey Mikasa\"…"))
        // TODO: initialize PorcupineManager here (see class doc) and call
        // onWakeWordDetected() from its callback.
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun onWakeWordDetected() {
        val container = (application as MikasaApplication).container
        updateNotification("Listening…")
        scope.launch {
            val languageTag = if (container.securePrefs.preferredLanguage == "hindi") "hi-IN" else "en-IN"
            when (val result = container.speechToText.listenOnce(languageTag)) {
                is SpeechResult.Text -> {
                    updateNotification("Thinking…")
                    val event = container.conversationEngine.handleUserUtterance(result.text)
                    event.spokenReply?.let {
                        updateNotification(it.take(80))
                        container.textToSpeech.speak(it)
                    }
                    if (event.state == EngineState.AWAITING_CONFIRMATION) {
                        // Sensitive actions always confirm in the on-screen UI — bring it up.
                        startActivity(
                            Intent(this@AssistantForegroundService, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
                is SpeechResult.Error -> updateNotification("Didn't catch that.")
            }
            updateNotification("Listening for \"Hey Mikasa\"…")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        // TODO: PorcupineManager.stop() / .delete() here if wired in onCreate().
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(text: String): Notification {
        val channelId = "mikasa_assistant_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Mikasa Assistant", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Mikasa")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(text))
    }

    companion object {
        private const val NOTIFICATION_ID = 4201
    }
}
