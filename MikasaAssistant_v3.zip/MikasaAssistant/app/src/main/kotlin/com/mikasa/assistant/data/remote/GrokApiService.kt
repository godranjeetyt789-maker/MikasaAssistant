package com.mikasa.assistant.data.remote

import kotlinx.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Talks to xAI's Grok API (https://docs.x.ai/docs/api-reference).
 * OpenAI-compatible /v1/chat/completions endpoint, used both for plain replies
 * and for client-side function/tool calling (phone actions are executed on
 * the device, never on xAI's servers).
 */
class GrokApiService(private val apiKeyProvider: () -> String?) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val ENDPOINT = "https://api.x.ai/v1/chat/completions"
        // If grok-4.5 isn't enabled on your account yet, switch this to "grok-4.3".
        const val MODEL = "grok-4.5"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    suspend fun sendTurn(
        messages: List<ChatMessage>,
        tools: List<ToolDefinition>
    ): GrokTurnResult = suspendCancellableCoroutine { cont ->
        val apiKey = apiKeyProvider()
        if (apiKey.isNullOrBlank()) {
            cont.resume(GrokTurnResult.Error("No API key set yet — add your xAI key in Settings."))
            return@suspendCancellableCoroutine
        }

        val bodyJson = buildRequestBody(messages, tools).toString()
        val request = Request.Builder()
            .url(ENDPOINT)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(bodyJson.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        val call = client.newCall(request)
        cont.invokeOnCancellation { call.cancel() }

        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resume(GrokTurnResult.Error("Network error: ${e.message}"))
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val raw = it.body?.string().orEmpty()
                    val result = if (!it.isSuccessful) {
                        GrokTurnResult.Error("API error ${it.code}: ${raw.take(300)}")
                    } else {
                        try {
                            parseResponse(raw)
                        } catch (e: Exception) {
                            GrokTurnResult.Error("Couldn't parse response: ${e.message}")
                        }
                    }
                    if (cont.isActive) cont.resume(result)
                }
            }
        })
    }

    private fun buildRequestBody(messages: List<ChatMessage>, tools: List<ToolDefinition>): JSONObject {
        val messagesArray = JSONArray()
        for (m in messages) {
            val obj = JSONObject()
            obj.put("role", m.role)
            obj.put("content", m.content ?: JSONObject.NULL)
            m.name?.let { obj.put("name", it) }
            m.toolCallId?.let { obj.put("tool_call_id", it) }
            m.toolCalls?.let { calls ->
                val tcArray = JSONArray()
                for (tc in calls) {
                    val tcObj = JSONObject()
                    tcObj.put("id", tc.id)
                    tcObj.put("type", "function")
                    val fn = JSONObject()
                    fn.put("name", tc.functionName)
                    fn.put("arguments", tc.functionArgumentsJson)
                    tcObj.put("function", fn)
                    tcArray.put(tcObj)
                }
                obj.put("tool_calls", tcArray)
            }
            messagesArray.put(obj)
        }

        val root = JSONObject()
        root.put("model", MODEL)
        root.put("messages", messagesArray)
        root.put("temperature", 0.7)

        if (tools.isNotEmpty()) {
            val toolsArray = JSONArray()
            for (t in tools) {
                val toolObj = JSONObject()
                toolObj.put("type", "function")
                val fn = JSONObject()
                fn.put("name", t.name)
                fn.put("description", t.description)
                fn.put("parameters", JSONObject(t.parametersJson))
                toolObj.put("function", fn)
                toolsArray.put(toolObj)
            }
            root.put("tools", toolsArray)
        }
        return root
    }

    private fun parseResponse(raw: String): GrokTurnResult {
        val json = JSONObject(raw)
        val choice = json.getJSONArray("choices").getJSONObject(0)
        val message = choice.getJSONObject("message")

        if (message.has("tool_calls") && !message.isNull("tool_calls")) {
            val tcArray = message.getJSONArray("tool_calls")
            val calls = mutableListOf<ToolCall>()
            for (i in 0 until tcArray.length()) {
                val tcObj = tcArray.getJSONObject(i)
                val fn = tcObj.getJSONObject("function")
                calls.add(
                    ToolCall(
                        id = tcObj.getString("id"),
                        functionName = fn.getString("name"),
                        functionArgumentsJson = fn.getString("arguments")
                    )
                )
            }
            return GrokTurnResult.ToolCalls(calls)
        }

        val text = if (message.has("content") && !message.isNull("content")) message.getString("content") else ""
        return GrokTurnResult.Reply(text)
    }
}
