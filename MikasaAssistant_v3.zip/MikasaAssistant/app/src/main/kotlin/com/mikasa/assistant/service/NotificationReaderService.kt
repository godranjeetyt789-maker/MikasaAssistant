package com.mikasa.assistant.service

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat

/**
 * Read-only notification summaries, purely on-demand (see ReadNotificationsTool).
 * Scope, by design:
 *  - Only exposes app name + title, never the full expanded body or actions.
 *  - Keeps only the current in-memory snapshot — nothing is logged, stored or
 *    sent anywhere unless the user explicitly asks "what are my notifications".
 *  - Never taps, dismisses, replies to, or otherwise acts on a notification.
 * Requires the user to manually grant Notification Access in
 * Settings > Apps > Special app access — Android does not allow this
 * permission to be granted silently by the app itself.
 */
class NotificationReaderService : NotificationListenerService() {

    data class NotificationSummary(val appName: String, val title: String)

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        refreshSnapshot()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance == this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) = refreshSnapshot()
    override fun onNotificationRemoved(sbn: StatusBarNotification) = refreshSnapshot()

    private fun refreshSnapshot() {
        snapshot = try {
            activeNotifications.mapNotNull { sbn ->
                val title = sbn.notification.extras.getCharSequence("android.title")?.toString()
                if (title.isNullOrBlank()) return@mapNotNull null
                val appName = try {
                    packageManager.getApplicationLabel(
                        packageManager.getApplicationInfo(sbn.packageName, 0)
                    ).toString()
                } catch (e: Exception) {
                    sbn.packageName
                }
                NotificationSummary(appName, title)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    companion object {
        @Volatile private var instance: NotificationReaderService? = null
        @Volatile private var snapshot: List<NotificationSummary> = emptyList()

        val isEnabled: Boolean get() = instance != null

        fun currentSnapshot(): List<NotificationSummary> = snapshot

        fun isPermissionGranted(context: Context): Boolean =
            NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

        fun openSettings(context: Context) {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
