package com.mikasa.assistant.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "conversation_messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface ConversationDao {
    @Insert
    suspend fun insert(message: MessageEntity)

    @Query("SELECT * FROM conversation_messages ORDER BY id DESC LIMIT :limit")
    suspend fun recent(limit: Int): List<MessageEntity>

    @Query("SELECT * FROM conversation_messages ORDER BY id ASC")
    fun observeAll(): Flow<List<MessageEntity>>

    @Query("DELETE FROM conversation_messages")
    suspend fun clearAll()
}

@Database(entities = [MessageEntity::class], version = 1, exportSchema = false)
abstract class ConversationDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
}
