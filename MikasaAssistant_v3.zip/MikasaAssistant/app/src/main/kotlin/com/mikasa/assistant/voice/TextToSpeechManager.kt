package com.mikasa.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID

/**
 * Wraps Android's on-device TextToSpeech engine. [speak] suspends until
 * playback finishes so the ViewModel can resume listening right after —
 * that's what makes the conversation feel like turn-taking rather than a
 * one-shot command box.
 */
class TextToSpeechManager(context: Context) {

    enum class Mood(val pitch: Float, val rate: Float) {
        NEUTRAL(1.0f, 1.0f),
        WARM(1.05f, 0.97f),
        EXCITED(1.15f, 1.1f),
        CALM(0.95f, 0.9f)
    }

    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                // Prefer Hindi so Hinglish sentences sound natural; TTS falls back
                // to the default voice automatically if Hindi data isn't installed.
                val result = tts?.setLanguage(Locale("hi", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.US)
                }
            }
        }
    }

    suspend fun speak(text: String, mood: Mood = Mood.NEUTRAL) {
        val engine = tts
        if (!ready || engine == null || text.isBlank()) return

        suspendCancellableCoroutine<Unit> { cont ->
            engine.setPitch(mood.pitch)
            engine.setSpeechRate(mood.rate)

            val utteranceId = UUID.randomUUID().toString()
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (cont.isActive) cont.resume(Unit)
                }
                @Deprecated("Deprecated in Java", ReplaceWith(""))
                override fun onError(utteranceId: String?) {
                    if (cont.isActive) cont.resume(Unit)
                }
            })

            cont.invokeOnCancellation { engine.stop() }
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        }
    }

    fun stop() = tts?.stop()

    fun shutdown() {
        tts?.shutdown()
        tts = null
    }
}
