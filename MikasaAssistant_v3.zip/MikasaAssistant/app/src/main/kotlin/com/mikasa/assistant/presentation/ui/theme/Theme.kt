package com.mikasa.assistant.presentation.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

// ── Jarvis / futuristic palette ────────────────────────────────────────────
val NeonCyan       = Color(0xFF00E5FF)
val ElectricViolet = Color(0xFF6C3CE9)
val DeepPurple     = Color(0xFF1A0A3C)
val SurfaceDark    = Color(0xFF0D0D1A)
val CardDark       = Color(0xFF15152B)
val OnSurface      = Color(0xFFE0E0FF)
val SubText        = Color(0xFF8080AA)
val UserBubble     = Color(0xFF1F1040)
val BotBubble      = Color(0xFF0A1530)
val ErrorRed       = Color(0xFFFF4C4C)

private val DarkColors = darkColorScheme(
    primary          = NeonCyan,
    onPrimary        = Color.Black,
    primaryContainer = ElectricViolet,
    onPrimaryContainer = Color.White,
    secondary        = ElectricViolet,
    onSecondary      = Color.White,
    background       = SurfaceDark,
    onBackground     = OnSurface,
    surface          = CardDark,
    onSurface        = OnSurface,
    surfaceVariant   = CardDark,
    onSurfaceVariant = SubText,
    error            = ErrorRed,
    onError          = Color.White
)

@Composable
fun MikasaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        content = content
    )
}
