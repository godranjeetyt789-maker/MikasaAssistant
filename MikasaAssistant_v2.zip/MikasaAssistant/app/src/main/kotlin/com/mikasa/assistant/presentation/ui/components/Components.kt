package com.mikasa.assistant.presentation.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mikasa.assistant.R
import com.mikasa.assistant.presentation.ui.theme.ElectricViolet
import com.mikasa.assistant.presentation.ui.theme.NeonCyan
import com.mikasa.assistant.presentation.ui.theme.SurfaceDark
import kotlin.math.sin

/**
 * Animated voice-waveform visualiser.
 * [amplitude] comes from the SpeechRecognizer's onRmsChanged callback (range
 * approximately 0-12 dB in practice). When [isActive] is false and amplitude
 * is 0, the bars show a quiet flat pulse so the UI never looks frozen.
 */
@Composable
fun VoiceWaveform(
    modifier: Modifier = Modifier,
    amplitude: Float = 0f,
    isActive: Boolean = false,
    barCount: Int = 28,
    barColor: Color = NeonCyan
) {
    val infinite = rememberInfiniteTransition(label = "wave")
    val phase by infinite.animateFloat(
        initialValue = 0f, targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing)), label = "phase"
    )
    val normalised = (amplitude.coerceIn(0f, 12f) / 12f).coerceAtLeast(0.08f)

    Canvas(modifier = modifier) {
        val barW = size.width / (barCount * 2f)
        val maxH = size.height * 0.85f
        val minH = size.height * 0.08f

        for (i in 0 until barCount) {
            val x = i * 2 * barW + barW / 2f
            val wave = sin(phase + i * 0.55).toFloat()
            val h = if (isActive)
                minH + (maxH - minH) * (0.4f + 0.6f * normalised) * ((wave + 1f) / 2f)
            else
                minH + (maxH - minH) * 0.12f * ((wave + 1f) / 2f)

            drawRoundRect(
                color = barColor.copy(alpha = 0.85f),
                topLeft = Offset(x, (size.height - h) / 2f),
                size = Size(barW * 0.7f, h),
                cornerRadius = CornerRadius(barW * 0.35f)
            )
        }
    }
}

/** Pulsing orb mic button — glows while [active]. */
@Composable
fun MicOrb(
    active: Boolean,
    onClick: () -> Unit,
    size: Dp = 72.dp
) {
    val infinite = rememberInfiniteTransition(label = "orb")
    val pulse by infinite.animateFloat(
        initialValue = 1f, targetValue = if (active) 1.18f else 1f,
        animationSpec = infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(size)
            .scale(if (active) pulse else 1f)
            .background(
                Brush.radialGradient(
                    colors = if (active)
                        listOf(NeonCyan.copy(alpha = 0.9f), ElectricViolet.copy(alpha = 0.7f))
                    else
                        listOf(ElectricViolet.copy(alpha = 0.6f), SurfaceDark),
                    radius = size.value * 2f
                ),
                shape = CircleShape
            )
            .border(
                width = if (active) 2.dp else 1.dp,
                color = if (active) NeonCyan else ElectricViolet.copy(alpha = 0.4f),
                shape = CircleShape
            )
            .clip(CircleShape)
            .clickable(onClick = onClick)
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_notification),
            contentDescription = if (active) "Stop listening" else "Tap to speak",
            tint = if (active) Color.Black else NeonCyan,
            modifier = Modifier.size(32.dp)
        )
    }
}

/** Animated cyan scan-line header ("MIKASA" logo bar). */
@Composable
fun JarvisHeader(name: String = "MIKASA") {
    val infinite = rememberInfiniteTransition(label = "scan")
    val scanAlpha by infinite.animateFloat(
        initialValue = 0.2f, targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "alpha"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = name,
            color = NeonCyan.copy(alpha = scanAlpha),
            fontSize = 26.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 8.sp
        )
        Box(
            modifier = Modifier
                .height(2.dp)
                .weight(1f)
                .padding(start = 16.dp)
                .background(
                    Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = scanAlpha), Color.Transparent))
                )
        )
    }
}

/** Rounded chat bubble for user and assistant messages. */
@Composable
fun ChatBubble(role: String, text: String) {
    val isUser = role == "user"
    Box(
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp, horizontal = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            if (!isUser) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(ElectricViolet, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("M", color = NeonCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(8.dp))
            }
            Text(
                text = text,
                color = if (isUser) NeonCyan else Color(0xFFD8D8FF),
                fontSize = 15.sp,
                lineHeight = 22.sp,
                modifier = Modifier
                    .background(
                        color = if (isUser) Color(0xFF1F1040) else Color(0xFF0A1530),
                        shape = RoundedCornerShape(
                            topStart = 18.dp, topEnd = 18.dp,
                            bottomStart = if (isUser) 18.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 18.dp
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
    }
}


