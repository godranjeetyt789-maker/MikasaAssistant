package com.mikasa.assistant.presentation.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mikasa.assistant.MikasaApplication
import com.mikasa.assistant.presentation.ui.theme.CardDark
import com.mikasa.assistant.presentation.ui.theme.ElectricViolet
import com.mikasa.assistant.presentation.ui.theme.NeonCyan
import com.mikasa.assistant.presentation.ui.theme.SurfaceDark
import com.mikasa.assistant.service.AssistantForegroundService
import com.mikasa.assistant.service.FloatingBubbleService
import com.mikasa.assistant.service.NotificationReaderService

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val prefs = (context.applicationContext as MikasaApplication).container.securePrefs

    var apiKey by remember { mutableStateOf(prefs.xaiApiKey ?: "") }
    var assistantName by remember { mutableStateOf(prefs.assistantName) }
    var savedMsg by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF0A0015), SurfaceDark))
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Text(
            "Settings",
            color = NeonCyan,
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 4.sp
        )
        Spacer(Modifier.height(24.dp))

        // ── API Key ──────────────────────────────────────────────────────
        SectionLabel("xAI (Grok) API Key")
        Text(
            "Your key is stored encrypted on this device only — never sent to us.",
            color = Color(0xFF8080AA),
            fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = apiKey,
            onValueChange = { apiKey = it },
            label = { Text("xai-…", color = Color(0xFF8080AA)) },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = fieldColors()
        )
        Spacer(Modifier.height(12.dp))

        // ── Assistant Name ───────────────────────────────────────────────
        SectionLabel("Assistant name")
        OutlinedTextField(
            value = assistantName,
            onValueChange = { assistantName = it },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = fieldColors()
        )
        Spacer(Modifier.height(16.dp))

        // ── Save ─────────────────────────────────────────────────────────
        Button(
            onClick = {
                prefs.xaiApiKey = apiKey.trim()
                prefs.assistantName = assistantName.trim().ifBlank { "Mikasa" }
                savedMsg = "Saved!"
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
        ) {
            Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
        }
        if (savedMsg.isNotEmpty()) {
            Text(savedMsg, color = NeonCyan, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        }

        Spacer(Modifier.height(28.dp))

        // ── Permissions ──────────────────────────────────────────────────
        SectionLabel("Permissions & Features")

        PermissionRow(
            label = "Floating bubble (overlay)",
            description = "Quick access bubble above other apps",
            granted = FloatingBubbleService.hasPermission(context),
            onRequest = { FloatingBubbleService.requestPermission(context) }
        )

        Spacer(Modifier.height(12.dp))

        PermissionRow(
            label = "Notification access",
            description = "Read notification summaries when you ask",
            granted = NotificationReaderService.isPermissionGranted(context),
            onRequest = { NotificationReaderService.openSettings(context) }
        )

        Spacer(Modifier.height(28.dp))

        // ── Start background service ──────────────────────────────────────
        SectionLabel("Background listening")
        Text(
            "Starts a foreground service (persistent notification shown by Android). Tap again to stop.",
            color = Color(0xFF8080AA),
            fontSize = 12.sp
        )
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                context.startForegroundService(
                    Intent(context, AssistantForegroundService::class.java)
                )
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet)
        ) {
            Text("Start background service", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = Color(0xFF9999CC), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun PermissionRow(label: String, description: String, granted: Boolean, onRequest: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardDark, RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, color = Color(0xFFD8D8FF), fontWeight = FontWeight.SemiBold)
                Text(description, color = Color(0xFF8080AA), fontSize = 12.sp)
            }
            if (!granted) {
                Button(
                    onClick = onRequest,
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet.copy(alpha = 0.6f))
                ) { Text("Grant", color = NeonCyan, fontSize = 12.sp) }
            } else {
                Text("✓ Granted", color = NeonCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = NeonCyan.copy(alpha = 0.5f),
    unfocusedBorderColor = ElectricViolet.copy(alpha = 0.3f),
    cursorColor = NeonCyan,
    focusedTextColor = Color(0xFFD8D8FF),
    unfocusedTextColor = Color(0xFFD8D8FF),
    focusedLabelColor = NeonCyan,
    unfocusedLabelColor = Color(0xFF8080AA)
)
