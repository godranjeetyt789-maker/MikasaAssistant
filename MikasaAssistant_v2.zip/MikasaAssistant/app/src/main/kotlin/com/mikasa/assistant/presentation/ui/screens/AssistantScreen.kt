package com.mikasa.assistant.presentation.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mikasa.assistant.presentation.ui.components.ChatBubble
import com.mikasa.assistant.presentation.ui.components.JarvisHeader
import com.mikasa.assistant.presentation.ui.components.MicOrb
import com.mikasa.assistant.presentation.ui.components.VoiceWaveform
import com.mikasa.assistant.presentation.ui.theme.CardDark
import com.mikasa.assistant.presentation.ui.theme.ElectricViolet
import com.mikasa.assistant.presentation.ui.theme.NeonCyan
import com.mikasa.assistant.presentation.ui.theme.SurfaceDark
import com.mikasa.assistant.presentation.viewmodel.AssistantState
import com.mikasa.assistant.presentation.viewmodel.AssistantViewModel

@Composable
fun AssistantScreen(vm: AssistantViewModel = viewModel()) {
    val uiState by vm.uiState.collectAsState()
    val listState = rememberLazyListState()
    var typedText by remember { mutableStateOf("") }

    val audioPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startListening()
    }

    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) listState.animateScrollToItem(uiState.messages.size - 1)
    }

    Scaffold(
        containerColor = SurfaceDark
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF0A0015), SurfaceDark, Color(0xFF000D20))
                    )
                )
        ) {

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .imePadding()
            ) {
                // ── Header ───────────────────────────────────────────────
                JarvisHeader()

                // ── Waveform ─────────────────────────────────────────────
                VoiceWaveform(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .padding(horizontal = 24.dp),
                    amplitude = uiState.amplitude,
                    isActive = uiState.state == AssistantState.LISTENING || uiState.state == AssistantState.SPEAKING
                )

                Spacer(Modifier.height(4.dp))

                // ── State badge ──────────────────────────────────────────
                val badgeText = when (uiState.state) {
                    AssistantState.IDLE -> null
                    AssistantState.LISTENING -> "Listening…"
                    AssistantState.THINKING -> "Thinking…"
                    AssistantState.SPEAKING -> "Speaking…"
                    AssistantState.AWAITING_CONFIRMATION -> "Confirmation needed"
                }
                if (badgeText != null) {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(CardDark, RoundedCornerShape(50))
                                .border(1.dp, NeonCyan.copy(alpha = 0.3f), RoundedCornerShape(50))
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            if (uiState.state == AssistantState.THINKING) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    color = NeonCyan,
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(8.dp))
                            }
                            Text(badgeText, color = NeonCyan, fontSize = 12.sp, letterSpacing = 1.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                // ── Error banner ─────────────────────────────────────────
                uiState.errorMessage?.let { err ->
                    Text(
                        text = err,
                        color = Color(0xFFFF4C4C),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }

                // ── Chat messages ────────────────────────────────────────
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).padding(vertical = 8.dp),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    if (uiState.messages.isEmpty()) {
                        item {
                            Column(
                                modifier = Modifier.fillParentMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    "Namaste! Main Mikasa hoon.\nBoliye, main sunta hoon.",
                                    color = Color(0xFF606090),
                                    textAlign = TextAlign.Center,
                                    fontSize = 15.sp,
                                    lineHeight = 24.sp
                                )
                            }
                        }
                    } else {
                        items(uiState.messages) { msg -> ChatBubble(role = msg.role, text = msg.text) }
                    }
                }

                // ── Bottom bar: text input + mic orb ──────────────────────
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0D0D1A))
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = typedText,
                        onValueChange = { typedText = it },
                        placeholder = {
                            Text("Type a message…", color = Color(0xFF606090), fontSize = 14.sp)
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan.copy(alpha = 0.5f),
                            unfocusedBorderColor = ElectricViolet.copy(alpha = 0.3f),
                            cursorColor = NeonCyan,
                            focusedTextColor = Color(0xFFD8D8FF),
                            unfocusedTextColor = Color(0xFFD8D8FF)
                        ),
                        shape = RoundedCornerShape(28.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            vm.submitTypedText(typedText.trim())
                            typedText = ""
                        }),
                        modifier = Modifier.weight(1f),
                        maxLines = 3,
                        singleLine = false
                    )

                    Spacer(Modifier.width(12.dp))

                    MicOrb(
                        active = uiState.state == AssistantState.LISTENING,
                        onClick = {
                            if (uiState.state == AssistantState.IDLE) {
                                audioPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    )
                }
            }

            // ── Confirmation dialog ───────────────────────────────────────
            uiState.pendingConfirmation?.let { req ->
                AlertDialog(
                    onDismissRequest = { vm.confirmPendingAction(false) },
                    containerColor = CardDark,
                    shape = RoundedCornerShape(20.dp),
                    title = {
                        Text("Confirm", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    },
                    text = {
                        Text(req.summary, color = Color(0xFFD8D8FF), fontSize = 15.sp, lineHeight = 22.sp)
                    },
                    confirmButton = {
                        Button(
                            onClick = { vm.confirmPendingAction(true) },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                        ) { Text("Yes, do it", color = Color.Black, fontWeight = FontWeight.Bold) }
                    },
                    dismissButton = {
                        OutlinedButton(
                            onClick = { vm.confirmPendingAction(false) },
                            border = androidx.compose.foundation.BorderStroke(1.dp, ElectricViolet)
                        ) { Text("Cancel", color = ElectricViolet) }
                    }
                )
            }
        }
    }
}
